import pygame
import random
import os

def main():
    images = os.listdir("images")
    width = 480
    height = 400
    
    pygame.init()
    img=pygame.image.load("images\icon.png")
    img2=pygame.image.load("images\icon2.png")
    pygame.display.set_icon(img)
    pygame.display.set_caption("dumb pointless game")

    screen = pygame.display.set_mode((width,height))


    running = True
    img.set_alpha(300)
    while running:
        for a in range(0,len(images)):
            screen.blit(pygame.image.load("images\\"+images[a]),(random.randint(0,width),random.randint(0,height)))
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                running = False

if __name__=="__main__":
    main()
